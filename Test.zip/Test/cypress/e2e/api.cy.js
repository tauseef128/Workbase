import axios from 'axios';
import { expect } from 'chai';

describe('ReqRes API Testing', () => {
  const baseUrl = 'https://reqres.in/api';

  it('should return a list of users', () => {
    cy.request(`${baseUrl}/users`).then(response => {
      expect(response.status).to.equal(200);
      expect(response.body.data).to.be.an('array');
    });
  });

  it('should return details of a specific user', () => {
    const userId = 1;
    cy.request(`${baseUrl}/users/${userId}`).then(response => {
      expect(response.status).to.equal(200);
      expect(response.body.data).to.have.property('id', userId);
    });
  });

  it('should return a list of resources', () => {
    cy.request(`${baseUrl}/unknown`).then(response => {
      expect(response.status).to.equal(200);
      expect(response.body.data).to.be.an('array');
    });
  });

  it('should return details of a specific resource', () => {
    const resourceId = 1;
    cy.request(`${baseUrl}/unknown/${resourceId}`).then(response => {
      expect(response.status).to.equal(200);
      expect(response.body.data).to.have.property('id', resourceId);
    });
  });

  it('should return a list of all available users', () => {
    cy.request(`${baseUrl}/users?page=2`).then(response => {
      expect(response.status).to.equal(200);
      expect(response.body.data).to.be.an('array');
    });
  });

  it('should create a new user using POST request', () => {
    const userData = {
      name: 'John Doe',
      job: 'Tester'
    };
    cy.request('POST', `${baseUrl}/users`, userData).then(response => {
      expect(response.status).to.equal(201);
      expect(response.body).to.have.property('name', userData.name);
      expect(response.body).to.have.property('job', userData.job);
    });
  });

  it('should update user details using PUT request', () => {
    const userIdToUpdate = 2;
    const updatedUserData = {
      name: 'Updated Name',
      job: 'Developer'
    };
    cy.request('PUT', `${baseUrl}/users/${userIdToUpdate}`, updatedUserData).then(response => {
      expect(response.status).to.equal(200);
      expect(response.body).to.have.property('name', updatedUserData.name);
      expect(response.body).to.have.property('job', updatedUserData.job);
    });
  });

  it('should update user details using PATCH request', () => {
    const userIdToPatch = 3;
    const patchData = {
      job: 'Tester'
    };
    cy.request('PATCH', `${baseUrl}/users/${userIdToPatch}`, patchData).then(response => {
      expect(response.status).to.equal(200);
      expect(response.body).to.have.property('job', patchData.job);
    });
  });

  it('should delete a user using DELETE request', () => {
    const userIdToDelete = 4;
    cy.request('DELETE', `${baseUrl}/users/${userIdToDelete}`).then(response => {
      expect(response.status).to.equal(204);
    });
  });

  // Add more tests here
});
