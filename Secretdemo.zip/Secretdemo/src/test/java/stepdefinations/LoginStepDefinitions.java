package stepdefinations;// LoginStepDefinitions.java
import Pages.LoginPage;
import Pages.ProductsPage;
import io.cucumber.java.en.*;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.*;

public class LoginStepDefinitions {
    private WebDriver driver;
    private LoginPage loginPage;

    @Given("I am on the login page")
    public void iAmOnLoginPage() {
        System.setProperty("webdriver.chrome.driver", "/Users/ahmeetau/Documents/chromedriver_mac64/chromedriver");
        driver = new ChromeDriver();
        loginPage = new LoginPage(driver);
        driver.get("https://www.saucedemo.com/");
    }

    @When("I enter {string} as the username")
    public void enterUsername(String username) {
        loginPage.enterUsername(username);
    }

    @And("I enter {string} as the password")
    public void enterPassword(String password) {
        loginPage.enterPassword(password);
    }

    @And("I click the login button")
    public void clickLoginButton() {
        loginPage.clickLoginButton();
    }

    @Then("I should be logged in successfully")
    public void verifyLoginSuccess() {
        Assert.assertTrue(driver.getCurrentUrl().contains("inventory.html"), "Login failed");
    }


}
