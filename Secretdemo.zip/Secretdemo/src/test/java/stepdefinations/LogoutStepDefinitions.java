package stepdefinations;

import Pages.LoginPage;
import io.cucumber.java.en.*;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.*;

public class LogoutStepDefinitions {
    private WebDriver driver;
    private LoginPage loginPage;

    @Given("I am logged in")
    public void iAmLoggedIn() {
        System.setProperty("webdriver.chrome.driver", "/Users/ahmeetau/Documents/chromedriver_mac64/chromedriver");
        driver = new ChromeDriver();
        loginPage = new LoginPage(driver);
        driver.get("https://www.saucedemo.com/");
        loginPage.enterUsername("standard_user");
        loginPage.enterPassword("secret_sauce");
        loginPage.clickLoginButton();
    }

    @When("I click on the logout button")
    public void clickLogoutButton() {
        loginPage.logout();
    }

    @Then("I should be logged out successfully")
    public void verifyLogoutSuccess() {
        Assert.assertTrue(driver.getCurrentUrl().contains("saucedemo.com"), "Logout failed");
        driver.quit();
    }
}
